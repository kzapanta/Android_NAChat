package io.appium.java_client.pagefactory_tests.widgets.html.extended;

import io.appium.java_client.pagefactory_tests.widgets.html.annotated.AnnotatedHtmlMovies;
import org.openqa.selenium.WebElement;

public class ExtendedHtmlMovies extends AnnotatedHtmlMovies {
    protected ExtendedHtmlMovies(WebElement element) {
        super(element);
    }
}
