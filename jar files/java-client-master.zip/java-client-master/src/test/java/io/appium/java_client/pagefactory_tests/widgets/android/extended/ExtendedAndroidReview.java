package io.appium.java_client.pagefactory_tests.widgets.android.extended;

import io.appium.java_client.pagefactory_tests.widgets.android.annotated.AnnotatedAndroidReview;
import org.openqa.selenium.WebElement;

public class ExtendedAndroidReview extends AnnotatedAndroidReview {

    protected ExtendedAndroidReview(WebElement element) {
        super(element);
    }
}
