package io.appium.java_client.pagefactory_tests.widgets;

public interface WidgetTest {

    public void checkACommonWidget();

    public void checkAnAnnotatedWidget();

    public void checkAnExtendedWidget();

    public void checkTheLocatorOverridingOnAWidget();

}
