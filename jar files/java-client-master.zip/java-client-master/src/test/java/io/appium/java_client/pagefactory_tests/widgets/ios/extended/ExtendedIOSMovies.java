package io.appium.java_client.pagefactory_tests.widgets.ios.extended;

import io.appium.java_client.pagefactory_tests.widgets.ios.annotated.AnnotatedIOSMovies;
import org.openqa.selenium.WebElement;

public class ExtendedIOSMovies extends AnnotatedIOSMovies {
    protected ExtendedIOSMovies(WebElement element) {
        super(element);
    }
}
