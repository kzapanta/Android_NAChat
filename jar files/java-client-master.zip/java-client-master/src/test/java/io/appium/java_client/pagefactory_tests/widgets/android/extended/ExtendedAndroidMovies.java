package io.appium.java_client.pagefactory_tests.widgets.android.extended;

import io.appium.java_client.pagefactory_tests.widgets.android.annotated.AnnotatedAndroidMovies;
import org.openqa.selenium.WebElement;

public class ExtendedAndroidMovies extends AnnotatedAndroidMovies {

    protected ExtendedAndroidMovies(WebElement element) {
        super(element);
    }
}
