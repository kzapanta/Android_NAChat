package io.appium.java_client.pagefactory_tests.widgets.combined.extended;


import io.appium.java_client.pagefactory_tests.widgets.combined.annotated.AnnotatedCombinedMovies;
import org.openqa.selenium.WebElement;

public class ExtendedCombinedMovies extends AnnotatedCombinedMovies {
    protected ExtendedCombinedMovies(WebElement element) {
        super(element);
    }
}
