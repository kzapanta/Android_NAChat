package io.appium.java_client.pagefactory_tests.widgets.ios.extended;


import io.appium.java_client.pagefactory_tests.widgets.ios.annotated.AnnotatedIOSReview;
import org.openqa.selenium.WebElement;

public class ExtendedIOSReview extends AnnotatedIOSReview {
    protected ExtendedIOSReview(WebElement element) {
        super(element);
    }
}
