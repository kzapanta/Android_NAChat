#!bin/sh
OUTPUT="$(npm root -g)"
echo "${OUTPUT}"
exit